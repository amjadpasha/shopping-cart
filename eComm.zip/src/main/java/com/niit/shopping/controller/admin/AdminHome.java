package com.niit.shopping.controller.admin;

import com.niit.shopping.model.Customer;
import com.niit.shopping.model.Product;
import com.niit.shopping.service.CustomerService;
import com.niit.shopping.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/adminhome")
public class AdminHome {

    @Autowired
    private ProductService productService;

    @Autowired
    private CustomerService customerService;

    @RequestMapping
    public String adminhomePage(){
        return "adminhome";
    }

    @RequestMapping("/manageproducts")
    public String manageproducts(Model model){
        List<Product> products = productService.getProductList();
        model.addAttribute("products", products);

        return "manageproducts";
    }

    @RequestMapping("/customer")
    public String customerManagerment(Model model){

        List<Customer> customerList = customerService.getAllCustomers();
        model.addAttribute("customerList", customerList);

        return "managecustomer";
    }


} // The End of Class;
