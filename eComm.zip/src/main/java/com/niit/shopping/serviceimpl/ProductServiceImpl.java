package com.niit.shopping.serviceimpl;



import com.niit.shopping.dao.ProductDao;
import com.niit.shopping.model.Product;
import com.niit.shopping.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductDao productDao;

    public Product getProductById(int productId){
        return productDao.getProductById(productId);
    }

    public List<Product> getProductList(){
        return productDao.getProductList();
    }

    public void addproduct(Product product){
        productDao.addproduct(product);
    }

    public void editproduct(Product product){
        productDao.editproduct(product);
    }

    public void deleteProduct(Product product){
        productDao.deleteProduct(product);
    }


} // The End of Class;
