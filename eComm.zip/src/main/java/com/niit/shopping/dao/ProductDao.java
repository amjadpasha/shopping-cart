package com.niit.shopping.dao;


import com.niit.shopping.model.Product;

import java.util.List;

public interface ProductDao {

    List<Product> getProductList();

    Product getProductById (int id);

    void addproduct(Product product);

    void editproduct(Product product);

    void deleteProduct(Product product);
}
