package com.niit.shopping.dao;

import com.niit.shopping.model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
}
