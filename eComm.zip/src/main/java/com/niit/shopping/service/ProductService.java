package com.niit.shopping.service;


import com.niit.shopping.model.Product;

import java.util.List;

public interface ProductService {

    List<Product> getProductList();

    Product getProductById (int id);

    void addproduct(Product product);

    void editproduct(Product product);

    void deleteProduct(Product product);

}
